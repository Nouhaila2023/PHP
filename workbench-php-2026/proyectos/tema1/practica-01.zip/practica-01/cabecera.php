<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Libreria Online</title>
    <style>
body {
  background-color: #efdfefff; /* un fondo cálido */
  margin: 0;
  padding: 0;
}
</style>
    
</head>
<body>
    
<h2>LIBREBÍA JAROSO</h2>